import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class Simpl3Body91Comp extends PApplet {

//general
double G = 0.0000004981367808f; //Gravitational constant : Gm^3*Yg^-1*day^-2
//sun
float dSolar = 1.391f; // Diameter : Gm
double mSolar = 1989100000; // Mass : Yg
//mercury
double smaMercury = 57.9091f;
double mMercury = 330.22f;
double vMercury = 4.135968f;
float dMercury = 0.0048794f;
//venus
double mVenus = 4868;
double vVenus = 3.025728f; // Average orbital velocity : Gm/day
double smaVenus = 108.20893f; // Semi Major Axis : Gm
float dVenus = 0.0121036f;
//earth
double smaEarth = 149.598261f;
double mEarth = 5973.6f;
double vEarth = 2.572992f;
float dEarth = 0.0127420f;
//moon
double smaMoon = 0.384399f;
double mMoon = 73.477f;
double vMoon = 0.0883008f;
float dMoon = 0.0034742f;

Part p1, p2, p3;
double time = 0.0f;
int view = 1;
int views = 3;
int dataSize = 10000;
PFont font;
boolean showGUI = true;
boolean pause;
double dt = 0.1f;
float scale = 1;

float GmDay_KmSec = 625/54;
float Gm_Km = 1000000;
float Day_Sec = 86400;

public void setup(){
  size(screen.width,screen.height);//,OPENGL);
  smooth();
  font = loadFont("Serif-48.vlw");
  textFont(font, 12);
  
  restart();
}

public void draw(){
  background(0);
  if(!pause) particles();
  if(showGUI) GUI();
}

public void GUI(){
  showPlanets();
  showSlides();
  showInfo();
}

public void showPlanets(){
  float offY = height*0.92f;
  float offX = width*0.03f;
  float offP = height*0.04f;
  
  noStroke();
  fill(255,255,100);
  ellipse(offX, offY - offP*0, 10,10);
  fill(0,100,255);
  ellipse(offX, offY - offP*1, 10,10);
  fill(200,200,200);
  ellipse(offX, offY - offP*2, 10,10);
  
  strokeWeight(2);
  stroke(255);
  noFill();
  if(view == 1) ellipse(offX, offY - offP*0, 15,15);
  if(view == 0) ellipse(offX, offY - offP*1, 15,15);
  if(view == 2) ellipse(offX, offY - offP*2, 15,15);
  
  if(insideRect(mouseX, mouseY, offX, offY-offP*0,10)){
    showPlanetInfo(1);
    if(mousePressed){
      if(mouseButton == LEFT) view = 1;
      else{
        if(view==0) p2.trace =1;
        if(view==2) p3.trace =1;
      }
    }
  }
  if(insideRect(mouseX, mouseY, offX, offY-offP*1,10)){
    showPlanetInfo(2);
    if(mousePressed){
      if(mouseButton == LEFT) view = 0;
      else{
        if(view==0) p2.trace =0;
        if(view==2) p3.trace =2;
      }
    }
  }
  if(insideRect(mouseX, mouseY, offX, offY-offP*2,10)){
    showPlanetInfo(3);
    if(mousePressed){
      if(mouseButton == LEFT) view = 2;
      else{
        if(view==0) p2.trace =0;
        if(view==2) p3.trace =0;
      }
    }
  }
}

public void showPlanetInfo(int v){
  float offY = height*0.92f;
  float offX = width*0.06f;
  float offP = height*0.04f;
  
  Part p = new Part();
  if(v==1) p=p1;
  if(v==2) p=p2;
  if(v==3) p=p3;
  
  float vel = dist(0,0,(float)p.vx,(float)p.vy)*GmDay_KmSec;
  float dist0 = dist(0,0,(float)p.x,(float)p.y);
  
  fill(0,255,0);
  stroke(0,255,0);
  if(v==1) text("'Sun'",offX,offY-offP*0);
  if(v==2) text("'Earth' - rightclick on other planets to toggle trace mode",offX,offY-offP*0);
  if(v==3) text("'Moon' - rightclick on other planets to toggle trace mode",offX,offY-offP*0);
  text("Velocity: " + vel + " km/s",offX,offY-offP*1);
  text("Position: " + dist0 + " Gm",offX,offY-offP*2);
  
}

public void showSlides(){
  showScaleSlider();
  showTimeSlider();
}

boolean timeSliderGrab = false;

public void showTimeSlider(){
  float factor = 0.02f; // scale slider factor
  float offS=width*0.1f;
  float offX = width*0.02f;
  float offY = height*0.05f;
  float offXText = width*0.04f;
  float ballSize = width*0.02f;
  
  float tmpX = -log((float)dt)/factor+offX+offS; //1/(pow((dt*pow(factor,4)),0.25)+offX;
  if(mousePressed){
    if(insideRect(mouseX, mouseY, tmpX, height-offY,ballSize)) timeSliderGrab = true;
  }
  else timeSliderGrab=false;
  if(timeSliderGrab){
    dt = exp(-factor*(mouseX-offX-offS)); // exp((mouseX-offX)*factor);
  }
  
  float tmpW = abs(tmpX-offX);
  fill(0,255,0);
  text("dt: " + (float)dt*24 + " hours", tmpW + offXText, height-offY+5);
  
  noFill();
  stroke(125);
  strokeWeight(3);
  line(offX, height-offY, tmpX, height-offY);
  stroke(255);
  ellipse(tmpX,height-offY,ballSize*.5f,ballSize*.5f);
}

boolean scaleSliderGrab = false; // scale slider 'grabbed'

public void showScaleSlider(){
  float factor = 0.05f; // scale slider factor
  float offS=width*0.4f;
  float offX = width*0.02f;
  float offY = height*0.02f;
  float offXText = width*0.04f;
  float ballSize = width*0.02f;
  
  float tmpX = (factor*offX+log(scale))/factor+offS;
  if(mousePressed){
    if(insideRect(mouseX, mouseY, tmpX, height-offY,ballSize)) scaleSliderGrab = true;
  }
  else scaleSliderGrab=false;
  if(scaleSliderGrab){
    scale = exp(factor*(mouseX-offX-offS)); // exp((mouseX-offX)*factor);
  }
  
  float tmpW = abs(tmpX-offX);
  float tmpV = tmpW*1000000/scale;
  fill(0,255,0);
  text(tmpV + " m", tmpW + offXText, height-offY+5);
  
  noFill();
  stroke(125);
  strokeWeight(3);
  line(offX, height-offY, tmpX, height-offY);
  stroke(255);
  ellipse(tmpX,height-offY,ballSize*.5f,ballSize*.5f);
}

public boolean insideRect(float x1, float y1, float x2, float y2, float h){
  return(x1<x2+h*0.5f&&x1>x2-h*0.5f&&y1<y2+h*0.5f&&y1>y2-h*0.5f);
}

public void showInfo(){
  fill(0,255,0);
  text("Days: " + (int)time, width*0.02f, height*0.04f);
  stroke(255);
}

public void particles(){
  setAcc(p1, p2);
  setAcc(p1, p3);
  setAcc(p2, p3);

  p1.update(dt);
  p2.update(dt);
  p3.update(dt);

  time += dt;
  
  drawParticles();
}

public void drawParticles(){
  pushMatrix();
  if(view == 0) translate(width*0.5f-(float)p2.x*scale,height*0.5f-(float)p2.y*scale);
  if(view == 1) translate(width*0.5f-(float)p1.x*scale,height*0.5f-(float)p1.y*scale);
  if(view == 2) translate(width*0.5f-(float)p3.x*scale,height*0.5f-(float)p3.y*scale);
  scale(scale);
  p1.render(dSolar, color(255,255,0));
  p2.render(dEarth, color(0,200,255));
  p3.render(dMoon, color(200,200,200));
  popMatrix();
}

public void restart(){
  p1 = new Part(0,0,0,0,mSolar);
  p2 = new Part(0,smaEarth,vEarth,0,mEarth);
  p3 = new Part(0,smaEarth+smaMoon,vEarth+vMoon,0,mMoon);
}

public void setAcc(Part p1, Part p2){
  double dx = p1.x-p2.x;
  double dy = p1.y-p2.y;
  double dist2 = dx*dx+dy*dy;
  double idist2 = 1/dist2;
  double ang = atan2((float)dy, (float)dx);//180/PI*atan( (float)(dy/dx) );
  double sinu = sin((float)ang);
  double cosi = cos((float)ang);

  p1.ax += -idist2*cosi*p2.m*G;
  p1.ay += -idist2*sinu*p2.m*G;
  p2.ax += idist2*cosi*p1.m*G;
  p2.ay += idist2*sinu*p1.m*G;
}

public void keyPressed(){
  if(key=='g') showGUI = !showGUI;
}

public float logX(float v, float x){
  return log(v)/log(x);
}
class Part{

  int trace = 1;
  int mp = 0;
  float[] mx = new float[dataSize];
  float[] my = new float[dataSize];
  float[] mvx = new float[dataSize];
  float[] mvy = new float[dataSize];
  double x, y, vx, vy, ax, ay, m, im, qm;

  Part(double _x,double _y,double _vx,double _vy,double _m){
    x=_x;
    y=_y;
    vx=_vx;
    vy=_vy;
    m=_m;
    calcMassVars();
  }

  Part(){
    standard();
  }

  Part(double _x, double _y){
    standard();
    x=_x;
    y=_y;
  }

  public void standard(){
    x=0;
    y=0;
    vx=0;
    vy=0;
    ax=0;
    ay=0;
    m=1;
    calcMassVars();
  }
  public void calcMassVars(){
    if(m==0){
      im=0;
      qm=1;
    }
    else{
      im=1/m;
      qm=sqrt((float)m);
    }
  }

  public void update(double dt){
    vx+=ax*dt;
    vy+=ay*dt;
    x+=vx*dt;
    y+=vy*dt;
    ax=.0f;
    ay=.0f;

    mx[mp%dataSize] = (float)x;
    my[mp%dataSize] = (float)y;
    mvx[mp%dataSize] = (float)vx;
    mvy[mp%dataSize] = (float)vy;
    mp ++;
  }

  public void render(float dia, int col){
    fill(col);
    ellipseMode(CENTER);
    noStroke();
    ellipse((float)x, (float)y, dia, dia);
    stroke(col);
    noFill();
    strokeWeight(0.5f/scale);
    ellipse((float)x, (float)y,10/scale,10/scale);

    if(trace == 1){
      beginShape();
      for(int i=0; i<dataSize; i++){
        int tmp = (i+mp)%dataSize;
        if(mx[tmp]!=0 && my[tmp]!=0) vertex(mx[tmp], my[tmp]);
      }
      vertex((float)x,(float)y);
      endShape();
    }
    if(trace == 2){
      beginShape();
      for(int i=0; i<dataSize; i++){
        int tmp = (i+mp)%dataSize;
        if(mx[tmp]!=0 && my[tmp]!=0) vertex((float)p2.x+mx[tmp]-p2.mx[tmp], (float)p2.y+my[tmp]-p2.my[tmp]);
      }
      vertex((float)x,(float)y);
      endShape();
    }
  }

}

public String simplify(String s){
  char[] c = new char[s.length()];
  int[] v = new int[s.length()];
  for(int i=0; i<s.length(); i++){
    c[i]=0;
    v[i]=0;
    int j=0;
    while(j<i && c[i] != c[j]) j++;
    c[j] = s.charAt(i);
    v[j] +=1;
    println(j);
  }
  String r = "";
  for(int i=0; i<s.length(); i++){
    r+=c[i];
    if(v[i] > 1) r+="^"+v[i];
  }
  return r;
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--stop-color=#cccccc", "Simpl3Body91Comp" });
  }
}
