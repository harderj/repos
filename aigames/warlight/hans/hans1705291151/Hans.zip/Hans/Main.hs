import Hans.Hans

main = hans
